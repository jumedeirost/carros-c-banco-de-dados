<h1>Cadastrar Proprietario</h1>

<form action="?page=salvar_proprietario" method="post">
<input type="hidden" name="acao" value="cadastrar">

<div class="container mb-3">
                <label class="mt-3">Nome</label>
                <input type="text" name="nome_modelo" class="form-control" placeholder="digite nome do proprietario">
            </div>
            <div class="container mb-3">
                <label class="mt-3">Telefone</label>
                <input type="text" name="cor_modelo" class="form-control" placeholder="digite o telefone do proprietario">
            </div>
            <div class="container mb-3">
                <label class="mt-3">CPF</label>
                <input type="text" name="ano_modelo" class="form-control" placeholder="digite o CPF do proprietario">

                <div class="container mb-3">
                <button type="submit" class="btn btn-primary">Cadastrar</button>
            </div>
            </div>    
    </div>
</div>
</form>




